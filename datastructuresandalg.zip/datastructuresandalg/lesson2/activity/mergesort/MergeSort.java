package com.packt.datastructuresandalg.lesson2.activity.mergesort;

public class MergeSort {

    private void merge(int[] array, int start, int middle, int end) {

    }

    private void mergeSort(int[] array, int start, int end) {

    }

    public void mergeSort(int[] array) {

    }
}
